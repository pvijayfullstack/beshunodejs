
const express = require("express");

const app = express();

const routes = require("./routes/students");

app.use(express.json())

app.use(express.urlencoded({
    extended: true
}));

app.set("view engine","ejs");

app.set("views","src/views/pages");

app.use('/static',express.static(`${__dirname}/public`));

app.use(routes);

const PORT = process.env.PORT  || 3000;

app.listen(PORT, () => {
    console.log(`app started on port ${PORT}`)
});
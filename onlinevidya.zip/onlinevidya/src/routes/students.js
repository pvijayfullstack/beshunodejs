const express = require("express");

const router = express.Router();

const Student = require('../controllers/Student');

//Get all Students.
router.get('/', async (req,res) => {

    let students = await new Student().getStudents();

    return res.render('home',{
        students
    });

});


//Create a Student.
router.post('/students', async (req,res) => {

    let { sno , name, phone, email, course } = req.body;

    await new Student().create({sno , name, phone, email, course}, res);

    return res.redirect('/')

});


module.exports = router;
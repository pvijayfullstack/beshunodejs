const Pool = require("pg").Pool;

const pool = new Pool({
    user:'postgres',
    host:'localhost',
    database:'online_vidya_db',
    password:'postgres',
    port:'5432'
});

module.exports = pool;
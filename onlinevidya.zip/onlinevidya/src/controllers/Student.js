const db = require('../config/db');

class Student {

    //get all student.
    async getStudents(){

        let results = await db.query(
            `SELECT * FROM students`
        ).catch(console.log);

        return results && results.rows || [];
    };

    //create a student.
    async create(student){

        await db.query('INSERT INTO todos (sno , name, phone, email, course) VALUES ($1, $2, $3, $4, $5)',
        [student.sno, student.name, student.phone, student.email, student.course]
        )
        .catch(console.log);

        return;        
    };

};

module.exports = Student;